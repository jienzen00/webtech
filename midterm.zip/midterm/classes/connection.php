<?php
$host = 'localhost';
$dbname = 'online_ordering_system';
$user = 'root';
$pass = '';
$connection = new PDO("mysql:host=$host;dbname=$dbname;charset=UTF8",$user,$pass);
?>