<?php 

include('view/view_restaurant.php');



?>